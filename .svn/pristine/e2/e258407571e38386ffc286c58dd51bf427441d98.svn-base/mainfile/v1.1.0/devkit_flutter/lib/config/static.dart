import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class StaticVarMethod{
  static bool isInitLocalNotif = false;
  static FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  static bool isDarkMode = false;
}