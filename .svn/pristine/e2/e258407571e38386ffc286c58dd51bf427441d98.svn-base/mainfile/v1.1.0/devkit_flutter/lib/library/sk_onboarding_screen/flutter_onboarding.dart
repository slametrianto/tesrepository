library flutter_onboarding;

export 'package:devkitflutter/library/sk_onboarding_screen/flutter_onboarding.dart';
export 'package:devkitflutter/library/sk_onboarding_screen/sk_onboarding_model.dart';
