/*
This is api provider
This page is used to get data from API
 */

import 'package:devkitflutter/config/constant.dart';
import 'package:devkitflutter/model/integration/student_model.dart';
import 'package:dio/dio.dart';

class ApiProvider {
  Dio dio = Dio();
  Response response;
  String connErr = 'Please check your internet connection and try again';

  Future<Response> getConnect(url, apiToken) async{
    print('url : '+url.toString());
    try{
      dio.options.headers['content-Type'] = 'application/x-www-form-urlencoded';
      dio.options.connectTimeout = 30000; //5s
      dio.options.receiveTimeout = 25000;

      return await dio.post(url, cancelToken: apiToken);
    } on DioError catch (e){
      //print(e.toString()+' | '+url.toString());
      if(e.type == DioErrorType.RESPONSE){
        int statusCode = e.response.statusCode;
        if(statusCode == STATUS_NOT_FOUND){
          throw Exception("Api not found");
        } else if(statusCode == STATUS_INTERNAL_ERROR){
          throw Exception("Internal Server Error");
        } else {
          throw Exception(e.error.message.toString());
        }
      } else if(e.type == DioErrorType.CONNECT_TIMEOUT){
        throw Exception(e.message.toString());
      } else if(e.type == DioErrorType.CANCEL){
        throw Exception('cancel');
      }
      throw Exception(connErr);
    } finally{
      dio.close();
    }
  }

  Future<Response> postConnect(url, data, apiToken) async{
    print('url : '+url.toString());
    print('postData : '+data.toString());
    try{
      dio.options.headers['content-Type'] = 'application/x-www-form-urlencoded';
      dio.options.connectTimeout = 30000; //5s
      dio.options.receiveTimeout = 25000;

      return await dio.post(url, data: data, cancelToken: apiToken);
    } on DioError catch (e){
      print(e.toString()+' | '+url.toString());
      if(e.type == DioErrorType.RESPONSE){
        int statusCode = e.response.statusCode;
        if(statusCode == STATUS_NOT_FOUND){
          throw Exception("Api not found");
        } else if(statusCode == STATUS_INTERNAL_ERROR){
          throw Exception("Internal Server Error");
        } else {
          throw Exception(e.error.message.toString());
        }
      } else if(e.type == DioErrorType.CONNECT_TIMEOUT){
        throw Exception(e.message.toString());
      } else if(e.type == DioErrorType.CANCEL){
        throw Exception('cancel');
      }
      throw Exception(connErr);
    } finally{
      dio.close();
    }
  }

  Future<String> getExample(apiToken) async {
    response = await getConnect(SERVER_URL+'/example/getData', apiToken);
    print('res : '+response.toString());
    return response.data.toString();
  }

  Future<String> postExample(String id, apiToken) async {
    var postData = {
      'id': id
    };
    response = await postConnect(SERVER_URL+'/example/postData', postData, apiToken);
    print('res : '+response.toString());
    return response.data.toString();
  }

  Future<List<StudentModel>> getStudent(String sessionId, apiToken) async {
    var postData = {
      'session_id': sessionId
    };
    response = await postConnect(SERVER_URL+'/student/getStudent', postData, apiToken);
    List responseList = response.data['data'];
    if(response.data['status'] == STATUS_OK){
      List<StudentModel> listData = responseList.map((f) => StudentModel.fromJson(f)).toList();
      return listData;
    } else {
      throw Exception(response.data['msg']);
    }
  }

  Future<List<dynamic>> addStudent(String sessionId, String studentName, String studentPhoneNumber, String studentGender, String studentAddress, apiToken) async {
    var postData = {
      'session_id': sessionId,
      'student_name': studentName,
      'student_phone_number': studentPhoneNumber,
      'student_gender': studentGender,
      'student_address': studentAddress,
    };
    response = await postConnect(SERVER_URL+'/student/addStudent', postData, apiToken);
    if(response.data['status'] == STATUS_OK){
      List<dynamic> respList = List();
      respList.add(response.data['msg']);
      respList.add(response.data['data']['id']);
      return respList;
    } else {
      throw Exception(response.data['msg']);
    }
  }

  Future<String> editStudent(String sessionId, int studentId, String studentName, String studentPhoneNumber, String studentGender, String studentAddress, apiToken) async {
    var postData = {
      'session_id': sessionId,
      'student_id': studentId,
      'student_name': studentName,
      'student_phone_number': studentPhoneNumber,
      'student_gender': studentGender,
      'student_address': studentAddress,
    };
    response = await postConnect(SERVER_URL+'/student/editStudent', postData, apiToken);
    if(response.data['status'] == STATUS_OK){
      return response.data['msg'];
    } else {
      throw Exception(response.data['msg']);
    }
  }

  Future<String> deleteStudent(String sessionId, int studentId, apiToken) async {
    var postData = {
      'session_id': sessionId,
      'student_id': studentId,
    };
    response = await postConnect(SERVER_URL+'/student/deleteStudent', postData, apiToken);
    if(response.data['status'] == STATUS_OK){
      return response.data['msg'];
    } else {
      throw Exception(response.data['msg']);
    }
  }
}
