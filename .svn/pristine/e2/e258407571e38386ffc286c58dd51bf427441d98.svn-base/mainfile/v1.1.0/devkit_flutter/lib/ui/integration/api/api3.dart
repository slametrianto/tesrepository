import 'package:devkitflutter/bloc/student/bloc.dart';
import 'package:devkitflutter/config/constant.dart';
import 'package:devkitflutter/model/integration/student_model.dart';
import 'package:devkitflutter/ui/integration/api/add_data.dart';
import 'package:devkitflutter/ui/integration/api/edit_data.dart';
import 'package:devkitflutter/ui/reusable/global_function.dart';
import 'package:devkitflutter/ui/reusable/global_widget.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Api3Page extends StatefulWidget {
  @override
  _Api3PageState createState() => _Api3PageState();
}

class _Api3PageState extends State<Api3Page> {
  // initialize global widget
  final _globalWidget = GlobalWidget();
  final _globalFunction = GlobalFunction();

  StudentBloc _studentBloc;
  CancelToken apiToken = CancelToken(); // used to cancel fetch data from API

  List<StudentModel> studentData = List();

  @override
  void initState() {
    _studentBloc = BlocProvider.of<StudentBloc>(context);
    _studentBloc.add(GetStudent(sessionId: '5f0e6bfbafe255.00218389', apiToken: apiToken));
    super.initState();
  }

  @override
  void dispose() {
    apiToken.cancel("cancelled"); // cancel fetch data from API
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _globalWidget.globalAppBar(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: _globalWidget.createDetailWidget(
                  title: 'API 3 (Create Read Update Delete)',
                  desc: 'This is the example of Student Data\n- Cannot modify or delete Robert Steven & Claire\n- Max limit is 10 data)'
              ),
            ),
            Container(
                child: Wrap(
                  spacing: 16,
                  children: [
                    RaisedButton(
                      onPressed: (){
                        studentData.clear();
                        _studentBloc.add(GetStudent(sessionId: '5f0e6bfbafe255.00218389', apiToken: apiToken));
                      },
                      color: Colors.blue,
                      textColor: Colors.white,
                      child: Text('Refresh'),
                    ),
                    RaisedButton(
                      onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => AddDataPage()));
                      },
                      color: Colors.blue,
                      textColor: Colors.white,
                      child: Text('Add Data'),
                    )
                  ],
                )
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 8),
              child: Text('Data :', style: TextStyle(
                  fontSize: 18, color: BLACK21, fontWeight: FontWeight.w500
              )),
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 8),
              child: BlocListener<StudentBloc, StudentState>(
                listener: (context, state) {
                  if(state is GetStudentError) {
                    Fluttertoast.showToast(msg: state.errorMessage, toastLength: Toast.LENGTH_SHORT, backgroundColor: Colors.red, textColor: Colors.white, fontSize: 13);
                  }
                  if(state is DeleteStudentWaiting) {
                    Navigator.pop(context);
                    _globalFunction.showProgressDialog(context);
                  }
                  if(state is DeleteStudentError){
                    Navigator.pop(context);
                    Fluttertoast.showToast(msg: state.errorMessage, toastLength: Toast.LENGTH_SHORT, backgroundColor: Colors.red, textColor: Colors.white, fontSize: 13);
                  }
                  if(state is GetStudentSuccess) {
                    studentData.addAll(state.studentData);
                  }
                  if (state is DeleteStudentSuccess) {
                    Navigator.pop(context);
                    studentData.removeAt(state.index);
                    Fluttertoast.showToast(msg: state.msg, toastLength: Toast.LENGTH_SHORT);
                  }
                  if (state is AddStudentSuccess) {
                    Navigator.pop(context);
                    Navigator.pop(context);
                    studentData.insert(0, StudentModel(studentId: state.studentId, studentName: state.studentName, studentPhoneNumber: state.studentPhoneNumber, studentGender: state.studentGender, studentAddress: state.studentAddress));
                    Fluttertoast.showToast(msg: state.msg, toastLength: Toast.LENGTH_SHORT);
                  }
                  if (state is EditStudentSuccess) {
                    Navigator.pop(context);
                    Navigator.pop(context);
                    studentData[state.index] = StudentModel(studentId: state.studentId, studentName: state.studentName, studentPhoneNumber: state.studentPhoneNumber, studentGender: state.studentGender, studentAddress: state.studentAddress);
                    Fluttertoast.showToast(msg: state.msg, toastLength: Toast.LENGTH_SHORT);
                  }
                },
                child: BlocBuilder<StudentBloc, StudentState>(
                  builder: (context, state) {
                    if(state is GetStudentError) {
                      return Text('error occured');
                    } else {
                      if(studentData.length==0){
                        return Center(child: CircularProgressIndicator());
                      } else {
                        return ListView.builder(
                          itemCount: studentData.length,
                          shrinkWrap: true,
                          primary: false,
                          // Add one more item for progress indicator
                          padding: EdgeInsets.symmetric(vertical: 0),
                          itemBuilder: (BuildContext context, int index) {
                            return _buildStudentCard(index);
                          },
                        );
                      }
                    }
                  },
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildStudentCard(index){
    return Card(
      elevation: 0.5,
      child: Container(
        margin: EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              decoration: BoxDecoration(
                color: studentData[index].studentGender=='male'?Colors.blue:Colors.pink,
                borderRadius: BorderRadius.all(
                    Radius.circular(18)
                ),
              ),
              alignment: Alignment.center,
              width: 26,
              height: 26,
              child: Center(child: Text(studentData[index].studentGender=='male'?'M':'F', style: TextStyle(
                  color: Colors.white, fontSize: 12
              ))),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(studentData[index].studentName, style: TextStyle(
                      fontSize: 18, color: BLACK55, fontWeight: FontWeight.w500
                  )),
                  Text(studentData[index].studentAddress, style: TextStyle(
                      fontSize: 14, color: Colors.grey[600], fontWeight: FontWeight.w400
                  ))
                ],
              ),
            ),
            SizedBox(width: 12),
            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => EditDataPage(index:index, studentData: studentData[index])));
              },
              child: Icon(Icons.edit, size: 24, color: Colors.grey[700])
            ),
            SizedBox(width: 8),
            GestureDetector(
              onTap: (){
                showPopupDelete(index);
              },
              child: Icon(Icons.delete, size: 24, color: Colors.grey[700])
            ),
          ],
        ),
      ),
    );
  }

  void showPopupDelete(index) {
    // set up the buttons
    Widget cancelButton = FlatButton(
      child: Text('No', style: TextStyle(color: SOFT_BLUE)),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    Widget continueButton = FlatButton(
      child: Text('Yes', style: TextStyle(color: SOFT_BLUE)),
      onPressed: () {
        _studentBloc.add(DeleteStudent(sessionId: '5f0e6bfbafe255.00218389', studentId: studentData[index].studentId, index: index, apiToken: apiToken));
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      title: Text('Delete '+studentData[index].studentName, style: TextStyle(fontSize: 18),),
      content: Text('Are you sure to delete '+studentData[index].studentName+' ?', style: TextStyle(fontSize: 13)),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future progressDialog(BuildContext context) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () {
              return null;
            },
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        });
  }
}
