class ColorModel {
  final int id;
  final String color;

  ColorModel(this.id, this.color);
}