import 'package:devkitflutter/ui/integration/api/api_list.dart';
import 'package:devkitflutter/ui/integration/maps/maps_package_list.dart';
import 'package:devkitflutter/ui/integration/local_notification/local_notification_list.dart';
import 'package:devkitflutter/ui/reusable/global_widget.dart';
import 'package:flutter/material.dart';

class IntegrationTabPage extends StatefulWidget {
  @override
  _IntegrationTabPageState createState() => _IntegrationTabPageState();
}

class _IntegrationTabPageState extends State<IntegrationTabPage> {
  // initialize global widget
  final _globalWidget = GlobalWidget();

  int number = 1;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Tab(
      child: ListView(
        padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
        children: [
          _globalWidget.screenTabList(
              context: context,
              id: number++,
              icon: Icons.map,
              title: 'Maps',
              total: 14,
              page: MapsPackageListPage()
          ),
          _globalWidget.screenTabList(
              context: context,
              id: number++,
              icon: Icons.notifications_active,
              title: 'Local Notification',
              total: 5,
              page: LocalNotificationListPage()
          ),
          _globalWidget.screenTabList(
              context: context,
              id: number++,
              icon: Icons.sync_alt,
              title: 'Get Data from API',
              total: 5,
              page: ApiListPage()
          )
        ],
      ),
    );
  }
}
