<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Authentication extends MY_Controller {
	
	public function __construct()
	{
		// Global
		parent::__construct();

		$this->load->model('model_user');
	}
	
	function login(){
		$email	= $this->custom_security->anti_injection($this->input->post('email'));
		$password	= $this->custom_security->anti_injection($this->input->post('password'));

		$pattern = "/^[-_a-z0-9\'+*$^&%=~!?{}]++(?:\.[-_a-z0-9\'+*$^&%=~!?{}]+)*+@(?:(?![-.])[-a-z0-9.]+(?<![-.])\.[a-z]{2,6}|\d{1,3}(?:\.\d{1,3}){3})(?::\d++)?$/iD";
		
		$error = '';
		if(empty($email)){
			$error = 'Email can not be empty';
		} else if(!preg_match($pattern, $email)){
			$error = 'Please enter a valid email';
		} else if(empty($password)){
			$error = 'Password can not be empty';
		}

		if(!empty($error)){
			$json['status'] = STATUS_BAD_REQUEST;
			$json['msg'] = $error;
		} else {
			$rsData = array();
			$rsLogin = $this->model_user->checkLogin($email, $password);
			if($rsLogin){
				$uniq = uniqid("", TRUE);
				$insertSession = $this->model_user->insertSession($uniq, $rsLogin[0]['user_id']);

				foreach($rsLogin as $k => $v){
					$rsData[$k]['email'] = $v['email'];
					$rsData[$k]['fullName'] = $v['name'];
					$rsData[$k]['phoneNumber'] = $v['phone_number'];
					$rsData[$k]['sessionId'] = $uniq;
				}
				
				$json['status'] = STATUS_OK;
				$json['msg'] = 'Success';
				$json['data'] = $rsData;
			} else {
				$json['status'] = STATUS_BAD_REQUEST;
				$json['msg'] = 'Failed to login, please check your email and password again';
			}
		}
		header("Content-Type: application/json");
		echo json_encode($json);
	}
}