<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Example extends MY_Controller {
	
	public function __construct()
	{
		// Global
		parent::__construct();
	}

	function getData(){
		usleep(400000);
		echo 'My name is robert steven';
	}

	function postData(){
		usleep(400000);
		$id	= $this->custom_security->anti_injection($this->input->post('id'));
		echo 'My id is '.$id;
	}
}