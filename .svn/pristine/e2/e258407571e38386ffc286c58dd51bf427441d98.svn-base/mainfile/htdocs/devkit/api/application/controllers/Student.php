<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student extends MY_Controller {
	
	public function __construct()
	{
		// Global
		parent::__construct();

		$this->load->model('model_user');
		$this->load->model('model_student');
		$this->load->helper('funcglobal');
	}

	function getStudent(){
		usleep(400000);
		$sessionId	= $this->custom_security->anti_injection($this->input->post('session_id'));
		$userId 	= $this->model_user->decodeSession($sessionId);
		
		if($userId==0) {
			$json['status'] = STATUS_BAD_REQUEST;
			$json['msg'] = 'Session Expired';
		} else {
			$rsData = array();
			$rs = $this->model_student->getStudent();
			if($rs){
				foreach($rs as $k => $v){
					$rsData[$k]['studentId'] = (int) $v['student_id'];
					$rsData[$k]['studentName'] = $v['student_name'];
					$rsData[$k]['studentPhoneNumber'] = $v['student_phone_number'];
					$rsData[$k]['studentGender'] = $v['student_gender'];
					$rsData[$k]['studentAddress'] = $v['student_address'];
				}
			}
			$json['status'] = STATUS_OK;
			$json['msg'] = 'Success';
			$json['data'] = $rsData;
		}
		header("Content-Type: application/json");
		echo json_encode($json);
	}

	function addStudent(){
		$session_id		= $this->custom_security->anti_injection($this->input->post('session_id'));
		$studentName	= $this->custom_security->anti_injection($this->input->post('student_name'));
		$studentPhoneNumber	= $this->custom_security->anti_injection($this->input->post('student_phone_number'));
		$studentGender 		= $this->custom_security->anti_injection($this->input->post('student_gender'));
		$studentAddress 		= $this->custom_security->anti_injection($this->input->post('student_address'));
		
		$user_id = $this->model_user->decodeSession($session_id);
		
		$error = '';
		
		if($user_id==0) {
			$error = 'Session Expired';
		} else if(empty($studentName)) {
			$error = 'Student name can not be empty';
		} else if(empty($studentPhoneNumber)) {
			$error = 'Student phone number can not be empty';
		} else if(empty($studentGender)) {
			$error = 'Student gender can not be empty';
		} else if(empty($studentAddress)) {
			$error = 'Student address can not be empty';
		}
		
		if(!empty($error)){
			$json['status'] = STATUS_BAD_REQUEST;
			$json['msg'] = $error;
		} else {
			$countStudent = $this->model_student->getCountStudent();
			if($countStudent < 10){
				$insert = $this->model_student->insertStudent($studentName, $studentPhoneNumber, $studentGender, $studentAddress);
				
				$json['status'] = STATUS_OK;
				$json['msg'] = "Add student success";
				$data['id'] = $insert;
				$json['data'] = $data;
			} else {
				$json['status'] = STATUS_BAD_REQUEST;
				$json['msg'] = 'Maximum limit is 10, delete data first';
			}
		}
		header("Content-Type: application/json");
		echo json_encode($json);
	}

	function editStudent(){
		$session_id		= $this->custom_security->anti_injection($this->input->post('session_id'));
		$studentId	= $this->custom_security->anti_injection($this->input->post('student_id'));
		$studentName	= $this->custom_security->anti_injection($this->input->post('student_name'));
		$studentPhoneNumber	= $this->custom_security->anti_injection($this->input->post('student_phone_number'));
		$studentGender 		= $this->custom_security->anti_injection($this->input->post('student_gender'));
		$studentAddress 		= $this->custom_security->anti_injection($this->input->post('student_address'));
		
		$user_id = $this->model_user->decodeSession($session_id);
		
		$error = '';
		
		if($user_id==0) {
			$error = 'Session Expired';
		} else if(empty($studentId)) {
			$error = 'Student id can not be empty';
		} else if(empty($studentName)) {
			$error = 'Student name can not be empty';
		} else if(empty($studentPhoneNumber)) {
			$error = 'Student phone number can not be empty';
		} else if(empty($studentGender)) {
			$error = 'Student gender can not be empty';
		} else if(empty($studentAddress)) {
			$error = 'Student address can not be empty';
		}  else if($studentId==1 || $studentId==2){
			$error = 'Cannot edit Robert Steven or Claire';
		}
		
		if(!empty($error)){
			$json['status'] = STATUS_BAD_REQUEST;
			$json['msg'] = $error;
		} else {
			$update = $this->model_student->editStudent($studentId, $studentName, $studentPhoneNumber, $studentGender, $studentAddress);
			
			$json['status'] = STATUS_OK;
			$json['msg'] = "Edit student success";
		}
		header("Content-Type: application/json");
		echo json_encode($json);
	}

	function deleteStudent(){
		$session_id	= $this->custom_security->anti_injection($this->input->post('session_id'));
		$id		= $this->custom_security->anti_injection($this->input->post('student_id'));
		
		$user_id = $this->model_user->decodeSession($session_id);
		
		$error = '';
		
		if($user_id==0) {
			$error = 'Session Expired';
		} else if(empty($id)) {
			$error = 'ID can not be empty';
		} else if($id==1 || $id==2){
			$error = 'Cannot delete Robert Steven or Claire';
		}
		
		if(!empty($error)){
			$json['status'] = STATUS_BAD_REQUEST;
			$json['msg'] = $error;
		} else {
			$deleteStudent = $this->model_student->deleteStudent($id);
			
			$json['status'] = STATUS_OK;
			$json['msg'] = "success";
		}
		header("Content-Type: application/json");
		echo json_encode($json);
	}
}