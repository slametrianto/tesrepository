<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_user extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}
	
	function decodeSession($sessionId){
		$sql	= "SELECT user_id FROM tbl_session WHERE session_id=?";	
		$query	= $this->db->query($sql, array($sessionId));
		$rs		= $query->result_array(); 
		
		$uid=0;
		if($rs){
			$uid = $rs[0]['user_id'];
		}
		
		return $uid;
	}

	function checkLogin($email, $password)
	{
		$sql	= "SELECT user_id, email, name, phone_number FROM tbl_user WHERE email=? AND password = ?";
		$query	= $this->db->query($sql, array($email, $password));
		$rs		= $query->result_array(); 
		
		return $rs;	
	}

	function insertSession($uniq, $userId){
		$sql	= 'INSERT INTO tbl_session SET session_id=?, user_id=?, login_date=now()';	
		return $this->db->query($sql, array($uniq, $userId));
	}
}