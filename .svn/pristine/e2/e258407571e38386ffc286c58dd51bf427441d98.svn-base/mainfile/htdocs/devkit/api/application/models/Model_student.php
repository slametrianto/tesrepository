<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_student extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	function getStudent()
	{
		$sql	= "SELECT * FROM tbl_student WHERE 1 ORDER BY student_id DESC";
		$query	= $this->db->query($sql);
		$rs		= $query->result_array();
		
		return $rs;
	}

	function getCountStudent()
	{
		$sql	= "SELECT count(0) as count FROM tbl_student WHERE 1";
		$query	= $this->db->query($sql);
		$rs		= $query->result_array();
		
		return $rs[0]['count'];
	}

	function insertStudent($studentName, $studentPhoneNumber, $studentGender, $studentAddress)
	{
		$sql	= "INSERT INTO tbl_student set student_name=?, student_phone_number=?, student_gender=?, student_address=?";
		$query  = $this->db->query($sql, array($studentName, $studentPhoneNumber, $studentGender, $studentAddress));
		$last_id  = $this->db->insert_id();
		
		return $last_id;
	}

	function editStudent($id = '', $studentName, $studentPhoneNumber, $studentGender, $studentAddress)
	{
		$sql	= "UPDATE tbl_student set student_name=?, student_phone_number=?, student_gender=?, student_address=? where student_id=?";
		$query	= $this->db->query($sql, array($studentName, $studentPhoneNumber, $studentGender, $studentAddress, $id));
		
		return $query;
	}

	function deleteStudent($id = '')
	{
		$sql	= "DELETE FROM tbl_student where student_id=?";
		$query	= $this->db->query($sql, array($id));
		
		$str = $this->db->last_query();
		
		return $str;
	}
}